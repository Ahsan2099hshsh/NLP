document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const mainMenu = document.getElementById('mainMenu');
    const preprocessingSection = document.getElementById('preprocessingSection');
    const extractionSection = document.getElementById('extractionSection');
    const preprocessingCard = document.getElementById('preprocessingCard');
    const extractionCard = document.getElementById('extractionCard');
    const backBtn1 = document.getElementById('backToMenu');
    const backBtn2 = document.getElementById('backToMenu2');
    const inputText1 = document.getElementById('inputText');
    const inputText2 = document.getElementById('inputText2');
    const processPreprocessingBtn = document.getElementById('processPreprocessing');
    const processExtractionBtn = document.getElementById('processExtraction');
    const preprocessingResults = document.getElementById('preprocessingResults');
    const extractionResults = document.getElementById('extractionResults');

    // Show Preprocessing Section
    preprocessingCard.addEventListener('click', function() {
        mainMenu.classList.add('hidden');
        preprocessingSection.classList.remove('hidden');
        // Animate section in
        preprocessingSection.style.animation = 'slideInRight 0.5s ease-out';
    });

    // Show Extraction Section
    extractionCard.addEventListener('click', function() {
        mainMenu.classList.add('hidden');
        extractionSection.classList.remove('hidden');
        // Animate section in
        extractionSection.style.animation = 'slideInRight 0.5s ease-out';
    });

    // Back to Menu from Preprocessing
    backBtn1.addEventListener('click', function() {
        preprocessingSection.classList.add('hidden');
        mainMenu.classList.remove('hidden');
        // Clear inputs and results
        inputText1.value = '';
        preprocessingResults.innerHTML = '';
        preprocessingResults.classList.add('hidden');
    });

    // Back to Menu from Extraction
    backBtn2.addEventListener('click', function() {
        extractionSection.classList.add('hidden');
        mainMenu.classList.remove('hidden');
        // Clear inputs and results
        inputText2.value = '';
        extractionResults.innerHTML = '';
        extractionResults.classList.add('hidden');
    });

    // Process Preprocessing
    processPreprocessingBtn.addEventListener('click', async function() {
        const text = inputText1.value.trim();
        const checkboxes = preprocessingSection.querySelectorAll('input[type="checkbox"]:checked');
        const selected = Array.from(checkboxes).map(cb => cb.value);

        if (!text) {
            alert('Please enter some text!');
            return;
        }
        if (selected.length === 0) {
            alert('Please select at least one preprocessing option!');
            return;
        }

        try {
            preprocessingResults.innerHTML = '<p>Processing...</p>'; // Loading
            preprocessingResults.classList.remove('hidden');

            const response = await fetch('/preprocess', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text: text, selected: selected })
            });

            if (!response.ok) {
                throw new Error('Processing failed');
            }

            const data = await response.json();

            if (data.error) {
                throw new Error(data.error);
            }

            // Render results dynamically
            renderResults(preprocessingResults, data, 'preprocessing');
        } catch (error) {
            console.error('Error:', error);
            preprocessingResults.innerHTML = `<p style="color: red;">Error: ${error.message}</p>`;
        }
    });

    // Process Extraction
    processExtractionBtn.addEventListener('click', async function() {
        const text = inputText2.value.trim();
        const checkboxes = extractionSection.querySelectorAll('input[type="checkbox"]:checked');
        const selected = Array.from(checkboxes).map(cb => cb.value);

        if (!text) {
            alert('Please enter some text!');
            return;
        }
        if (selected.length === 0) {
            alert('Please select at least one extraction option!');
            return;
        }

        try {
            extractionResults.innerHTML = '<p>Processing...</p>'; // Loading
            extractionResults.classList.remove('hidden');

            const response = await fetch('/extract', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text: text, selected: selected })
            });

            if (!response.ok) {
                throw new Error('Processing failed');
            }

            const data = await response.json();

            if (data.error) {
                throw new Error(data.error);
            }

            // Render results dynamically
            renderResults(extractionResults, data, 'extraction');
        } catch (error) {
            console.error('Error:', error);
            extractionResults.innerHTML = `<p style="color: red;">Error: ${error.message}</p>`;
        }
    });

    // Helper: Render Results with Animations
    function renderResults(container, data, type) {
        container.innerHTML = ''; // Clear loading

        Object.keys(data).forEach((key, index) => {
            const card = document.createElement('div');
            card.className = 'result-card';
            card.style.animationDelay = `${index * 0.1}s`; // Staggered animation

            let content = `<h3>${getFeatureName(key, type)}</h3>`;

            if (key === 'cleaned_text') {
                content += `<p>${data[key]}</p>`;
            } else if (key === 'tokenization') {
                content += '<h4>Words:</h4><ul>' + data[key].words.map(w => `<li>${w}</li>`).join('') + '</ul>';
                content += '<h4>Sentences:</h4><ul>' + data[key].sentences.map(s => `<li>${s}</li>`).join('') + '</ul>';
            } else if (key === 'stopword_removal') {
                content += '<h4>Original Tokens:</h4><ul>' + data[key].original_tokens.map(w => `<li>${w}</li>`).join('') + '</ul>';
                content += '<h4>Filtered:</h4><ul>' + data[key].filtered.map(w => `<li>${w}</li>`).join('') + '</ul>';
            } else if (key === 'stemming' || key === 'lemmatization') {
                content += '<h4>Original:</h4><ul>' + data[key].original.map(w => `<li>${w}</li>`).join('') + '</ul>';
                content += '<h4>Processed:</h4><ul>' + data[key][key === 'stemming' ? 'stemmed' : 'lemmatized'].map(w => `<li>${w}</li>`).join('') + '</ul>';
            } else if (key === 'pos_tagging') {
                content += '<ul>' + data[key].tagged.map(t => `<li>(${t[0]}, ${t[1]})</li>`).join('') + '</ul>';
            } else if (key === 'bow' || key === 'tfidf') {
                content += `<p>Vector Length: ${data[key].full_length}</p>`;
                content += '<h4>Preview Vector (first 20):</h4><pre>' + JSON.stringify(data[key].vector, null, 2) + '</pre>';
                content += '<h4>Vocabulary (first 20):</h4><ul>' + data[key].vocab.map(v => `<li>${v}</li>`).join('') + '</ul>';
            } else if (key === 'embeddings') {
                content += '<h4>Word Vectors (first 10 dims, sample words):</h4><pre>' + JSON.stringify(data[key].vectors, null, 2) + '</pre>';
                if (data[key].similarity_example.length > 0) {
                    content += '<h4>Example Similarity:</h4><ul>' + data[key].similarity_example.map(s => `<li>${s[0]}: ${s[1].toFixed(4)}</li>`).join('') + '</ul>';
                }
            }

            card.innerHTML = content;
            container.appendChild(card);

            // Trigger animation
            setTimeout(() => card.classList.add('show'), 50);
        });
    }

    // Helper: Get readable feature names
    function getFeatureName(key, type) {
        const names = {
            tokenization: 'Tokenization Results',
            stopword_removal: 'Stop Word Removal',
            stemming: 'Stemming',
            lemmatization: 'Lemmatization',
            pos_tagging: 'POS Tagging',
            cleaned_text: 'Cleaned Text',
            bow: 'Bag of Words (BoW)',
            tfidf: 'TF-IDF',
            embeddings: 'Word Embeddings (Word2Vec)'
        };
        return names[key] || key;
    }
});